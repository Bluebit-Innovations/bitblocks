# lambda/noop.py
def handler(event, context):
    return {
        "statusCode": 200,
        "body": "Pentest alert suppressed."
    }
